#ifndef CAN_HARDWARE_COMMON__CORE__CAN_HAND_BASE_HPP_
#define CAN_HARDWARE_COMMON__CORE__CAN_HAND_BASE_HPP_

#include "can_hardware_common/core/command_result.hpp"
#include "can_hardware_common/core/lifecycle_plan.hpp"
#include "can_hardware_common/core/state_snapshot.hpp"
#include "can_hardware_common/core/write_plan.hpp"
#include "can_hardware_common/robot.hpp"

namespace can_hardware_common::core
{

class CanHandBase : public can_hardware_common::RobotIO
{
public:
  virtual ~CanHandBase() = default;

  bool read();
  bool write();
  bool enable(bool automatic_zeroing = false);
  bool disable();
  bool zero();

  const StateSnapshot & state_snapshot() const { return state_snapshot_; }
  const CommandResult & last_write_result() const { return last_write_result_; }
  const CommandResult & last_lifecycle_result() const { return last_lifecycle_result_; }

protected:
  virtual bool update_measurements_() = 0;
  virtual void refresh_state_snapshot_() = 0;

  virtual void build_ready_write_plan_(WritePlan & plan) = 0;
  virtual bool execute_write_plan_(const WritePlan & plan) = 0;

  virtual LifecyclePlan build_lifecycle_plan_(LifecycleOperation operation) = 0;
  virtual bool execute_lifecycle_plan_(const LifecyclePlan & plan) = 0;

  virtual void handle_precondition_failure_(const WritePlan & plan);
  virtual void handle_lifecycle_plan_failure_(const LifecyclePlan & plan);

  WritePlan build_write_plan_();
  bool run_lifecycle_operation_(LifecycleOperation operation);
  void finalize_write_result_(const WritePlan & plan, bool success);
  void finalize_lifecycle_result_(const LifecyclePlan & plan, bool success);

  StateSnapshot state_snapshot_;
  CommandResult last_write_result_;
  CommandResult last_lifecycle_result_;
};

}  // namespace can_hardware_common::core

#endif  // CAN_HARDWARE_COMMON__CORE__CAN_HAND_BASE_HPP_
