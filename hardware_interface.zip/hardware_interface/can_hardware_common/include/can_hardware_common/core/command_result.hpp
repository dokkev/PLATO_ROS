#ifndef CAN_HARDWARE_COMMON__CORE__COMMAND_RESULT_HPP_
#define CAN_HARDWARE_COMMON__CORE__COMMAND_RESULT_HPP_

#include <cstddef>

#include "can_hardware_common/core/plan_policies.hpp"

namespace can_hardware_common::core
{

struct CommandResult
{
  bool sent{false};
  bool confirmed{false};
  bool rejected{false};
  bool transport_error{false};
  bool timed_out{false};
  bool command_history_committed{false};
  std::size_t request_count{0};
  DispatchPolicy dispatch_policy{DispatchPolicy::kDirectFrames};
};

}  // namespace can_hardware_common::core

#endif  // CAN_HARDWARE_COMMON__CORE__COMMAND_RESULT_HPP_
