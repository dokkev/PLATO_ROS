#ifndef CAN_HARDWARE_COMMON__CORE__COMMAND_SNAPSHOT_HPP_
#define CAN_HARDWARE_COMMON__CORE__COMMAND_SNAPSHOT_HPP_

#include <cstddef>
#include <vector>

#include "can_hardware_common/robot.hpp"

namespace can_hardware_common::core
{

struct CommandSnapshot
{
  std::vector<double> position;
  std::vector<double> velocity;
  std::vector<double> effort;
  std::vector<double> stiffness;
  std::vector<double> damping;

  void clear()
  {
    position.clear();
    velocity.clear();
    effort.clear();
    stiffness.clear();
    damping.clear();
  }

  bool empty() const
  {
    return position.empty() &&
           velocity.empty() &&
           effort.empty() &&
           stiffness.empty() &&
           damping.empty();
  }

  std::size_t size() const
  {
    return position.size();
  }

  void capture(const can_hardware_common::RobotIO::Command::ConstView & view)
  {
    position.assign(view.position.data(), view.position.data() + view.size());
    velocity.assign(view.velocity.data(), view.velocity.data() + view.size());
    effort.assign(view.effort.data(), view.effort.data() + view.size());
    stiffness.assign(view.stiffness.data(), view.stiffness.data() + view.size());
    damping.assign(view.damping.data(), view.damping.data() + view.size());
  }
};

}  // namespace can_hardware_common::core

#endif  // CAN_HARDWARE_COMMON__CORE__COMMAND_SNAPSHOT_HPP_
