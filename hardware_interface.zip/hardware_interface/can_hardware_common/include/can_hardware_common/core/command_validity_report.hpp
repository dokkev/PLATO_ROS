#ifndef CAN_HARDWARE_COMMON__CORE__COMMAND_VALIDITY_REPORT_HPP_
#define CAN_HARDWARE_COMMON__CORE__COMMAND_VALIDITY_REPORT_HPP_

#include <string>

namespace can_hardware_common::core
{

struct CommandValidityReport
{
  bool all_finite{true};
  bool stale_state{false};
  bool mode_valid{true};
  bool within_limits{true};
  std::string reason;

  bool ok() const
  {
    return all_finite && !stale_state && mode_valid && within_limits;
  }
};

}  // namespace can_hardware_common::core

#endif  // CAN_HARDWARE_COMMON__CORE__COMMAND_VALIDITY_REPORT_HPP_
