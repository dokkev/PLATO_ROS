#ifndef CAN_HARDWARE_COMMON__CORE__LIFECYCLE_PLAN_HPP_
#define CAN_HARDWARE_COMMON__CORE__LIFECYCLE_PLAN_HPP_

#include <cstddef>
#include <string>
#include <vector>

#include <PCANBasic.h>

#include "can_hardware_common/actuator.hpp"
#include "can_hardware_common/core/plan_policies.hpp"

namespace can_hardware_common::core
{

enum class LifecycleOperation
{
  kEnable,
  kDisable,
  kZero,
};

enum class LifecycleFailureReason
{
  kNone,
  kPreconditionsNotMet,
  kTransportFault,
  kAckTimeout,
  kInvalidState,
};

struct LifecyclePlan
{
  LifecycleOperation operation{LifecycleOperation::kEnable};
  bool ready{false};
  bool return_error{true};
  std::string reason;
  DispatchPolicy dispatch_policy{DispatchPolicy::kDirectFrames};
  LifecycleFailureReason failure_reason{LifecycleFailureReason::kNone};
  std::vector<TPCANMsg> direct_frames;
  std::vector<can_hardware_common::CommandRequest> scheduled_requests;

  std::size_t request_count() const
  {
    return direct_frames.size() + scheduled_requests.size();
  }
};

}  // namespace can_hardware_common::core

#endif  // CAN_HARDWARE_COMMON__CORE__LIFECYCLE_PLAN_HPP_
