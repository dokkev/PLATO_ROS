#ifndef CAN_HARDWARE_COMMON__CORE__PLAN_POLICIES_HPP_
#define CAN_HARDWARE_COMMON__CORE__PLAN_POLICIES_HPP_

namespace can_hardware_common::core
{

enum class DispatchPolicy
{
  kDirectFrames,
  kScheduledRequests,
  kMixed,
  kCustomExecution,
};

inline const char * dispatch_policy_label(DispatchPolicy policy)
{
  switch (policy) {
    case DispatchPolicy::kDirectFrames:
      return "direct_frames";
    case DispatchPolicy::kScheduledRequests:
      return "scheduled_requests";
    case DispatchPolicy::kMixed:
      return "mixed";
    case DispatchPolicy::kCustomExecution:
      return "custom_execution";
  }

  return "unknown";
}

enum class CommandHistoryPolicy
{
  kNever,
  kOnSuccess,
  kAlways,
};

}  // namespace can_hardware_common::core

#endif  // CAN_HARDWARE_COMMON__CORE__PLAN_POLICIES_HPP_
