#ifndef CAN_HARDWARE_COMMON__CORE__STATE_SNAPSHOT_HPP_
#define CAN_HARDWARE_COMMON__CORE__STATE_SNAPSHOT_HPP_

#include <cstddef>
#include <vector>

#include <Eigen/Core>
#include <rclcpp/time.hpp>

#include "can_hardware_common/actuator.hpp"

namespace can_hardware_common::core
{

struct StateSnapshot
{
  // Contract:
  // - stamp: snapshot capture time after the current read/refresh step completes.
  // - has_fresh_rx: robot-critical RX state used for command safety is fresh enough for this cycle.
  // - calibrated: required joint/actuator calibration or offset state is valid.
  // - sensors_ok: required external sensors are both available and fresh.
  // - actuators_ready: actuator feedback/commandability has reached the robot-specific ready threshold.
  // - transport_healthy: transport/polling status is healthy enough to keep streaming commands active.
  // - lifecycle_busy: an exclusive lifecycle transition is in progress, so stream writes must wait.
  // - model_ready: the hand-specific model has enough structural state to map joint <-> actuator data.
  //   This is intentionally separate from feedback freshness or actuator readiness.
  struct SensorStatus
  {
    std::size_t expected_count{0};
    std::size_t available_count{0};
    std::size_t fresh_count{0};

    bool all_available() const
    {
      return expected_count == 0 || available_count >= expected_count;
    }

    bool all_fresh() const
    {
      return expected_count == 0 || fresh_count >= expected_count;
    }

    bool ok() const
    {
      return all_available() && all_fresh();
    }
  };

  rclcpp::Time stamp{};
  bool has_fresh_rx{false};
  bool calibrated{false};
  bool sensors_ok{true};
  bool actuators_ready{false};
  bool transport_healthy{true};
  bool lifecycle_busy{false};
  bool model_ready{false};
  SensorStatus sensor_status{};

  Eigen::VectorXd joint_position;
  Eigen::VectorXd joint_velocity;
  Eigen::VectorXd joint_effort;

  std::vector<can_hardware_common::ActuatorState> actuator_states;

  void resize(std::size_t joint_count, std::size_t actuator_count)
  {
    joint_position.resize(static_cast<Eigen::Index>(joint_count));
    joint_velocity.resize(static_cast<Eigen::Index>(joint_count));
    joint_effort.resize(static_cast<Eigen::Index>(joint_count));
    actuator_states.assign(actuator_count, can_hardware_common::ActuatorState{});
  }
};

}  // namespace can_hardware_common::core

#endif  // CAN_HARDWARE_COMMON__CORE__STATE_SNAPSHOT_HPP_
