#ifndef CAN_HARDWARE_COMMON__CORE__WRITE_PLAN_HPP_
#define CAN_HARDWARE_COMMON__CORE__WRITE_PLAN_HPP_

#include <cstddef>
#include <string>
#include <vector>

#include <PCANBasic.h>

#include "can_hardware_common/actuator.hpp"
#include "can_hardware_common/core/command_snapshot.hpp"
#include "can_hardware_common/core/command_validity_report.hpp"
#include "can_hardware_common/core/plan_policies.hpp"

namespace can_hardware_common::core
{

enum class WriteBlockReason
{
  kNone,
  kInvalidCommand,
  kMissingFeedback,
  kNotCalibrated,
  kLifecycleBusy,
  kTransportFault,
  kModelNotReady,
};

struct WritePlan
{
  bool ready{false};
  bool return_error{false};
  bool stale_state{false};
  bool invalid_command{false};
  bool not_calibrated{false};
  std::string reason;
  DispatchPolicy dispatch_policy{DispatchPolicy::kDirectFrames};
  CommandHistoryPolicy command_history_policy{CommandHistoryPolicy::kOnSuccess};
  WriteBlockReason block_reason{WriteBlockReason::kNone};
  CommandValidityReport validity;
  CommandSnapshot desired_joint_command;
  CommandSnapshot computed_actuator_command;
  std::vector<TPCANMsg> direct_frames;
  std::vector<can_hardware_common::CommandRequest> scheduled_requests;

  std::size_t request_count() const
  {
    return direct_frames.size() + scheduled_requests.size();
  }
};

}  // namespace can_hardware_common::core

#endif  // CAN_HARDWARE_COMMON__CORE__WRITE_PLAN_HPP_
