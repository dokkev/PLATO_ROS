#include "can_hardware_common/core/can_hand_base.hpp"

#include <rclcpp/rclcpp.hpp>

namespace can_hardware_common::core
{

namespace
{

auto logger() { return rclcpp::get_logger("can_hand_base"); }

rclcpp::Clock & throttle_clock()
{
  static rclcpp::Clock clock(RCL_STEADY_TIME);
  return clock;
}

const char * lifecycle_operation_label(LifecycleOperation operation)
{
  switch (operation) {
    case LifecycleOperation::kEnable:
      return "enable";
    case LifecycleOperation::kDisable:
      return "disable";
    case LifecycleOperation::kZero:
      return "zero";
  }

  return "unknown";
}

const char * write_block_reason_label(WriteBlockReason reason)
{
  switch (reason) {
    case WriteBlockReason::kNone:
      return "none";
    case WriteBlockReason::kInvalidCommand:
      return "invalid_command";
    case WriteBlockReason::kMissingFeedback:
      return "missing_feedback";
    case WriteBlockReason::kNotCalibrated:
      return "not_calibrated";
    case WriteBlockReason::kLifecycleBusy:
      return "lifecycle_busy";
    case WriteBlockReason::kTransportFault:
      return "transport_fault";
    case WriteBlockReason::kModelNotReady:
      return "model_not_ready";
  }

  return "unknown";
}

bool should_commit_history(CommandHistoryPolicy policy, bool success)
{
  return policy == CommandHistoryPolicy::kAlways ||
         (policy == CommandHistoryPolicy::kOnSuccess && success);
}

}  // namespace

bool CanHandBase::read()
{
  if (!update_measurements_()) {
    return false;
  }

  refresh_state_snapshot_();
  return true;
}

bool CanHandBase::write()
{
  (void)update_measurements_();
  refresh_state_snapshot_();
  last_write_result_ = CommandResult{};

  const WritePlan plan = build_write_plan_();
  if (!plan.ready) {
    handle_precondition_failure_(plan);
    last_write_result_.request_count = plan.request_count();
    last_write_result_.dispatch_policy = plan.dispatch_policy;
    return !plan.return_error;
  }

  if (plan.request_count() == 0 && plan.dispatch_policy != DispatchPolicy::kCustomExecution) {
    RCLCPP_WARN_THROTTLE(
      logger(),
      throttle_clock(),
      1000,
      "Write plan is ready but contains no requests (dispatch=%s).",
      dispatch_policy_label(plan.dispatch_policy));
  }

  const bool success = execute_write_plan_(plan);
  finalize_write_result_(plan, success);
  return success;
}

bool CanHandBase::enable(bool automatic_zeroing)
{
  bool success = run_lifecycle_operation_(LifecycleOperation::kEnable);
  if (automatic_zeroing) {
    success = zero() && success;
  }
  return success;
}

bool CanHandBase::disable()
{
  return run_lifecycle_operation_(LifecycleOperation::kDisable);
}

bool CanHandBase::zero()
{
  return run_lifecycle_operation_(LifecycleOperation::kZero);
}

bool CanHandBase::run_lifecycle_operation_(LifecycleOperation operation)
{
  last_lifecycle_result_ = CommandResult{};
  const LifecyclePlan plan = build_lifecycle_plan_(operation);
  if (!plan.ready) {
    handle_lifecycle_plan_failure_(plan);
    last_lifecycle_result_.request_count = plan.request_count();
    last_lifecycle_result_.dispatch_policy = plan.dispatch_policy;
    return !plan.return_error;
  }

  if (plan.request_count() == 0 && plan.dispatch_policy != DispatchPolicy::kCustomExecution) {
    RCLCPP_WARN_THROTTLE(
      logger(),
      throttle_clock(),
      1000,
      "Lifecycle plan '%s' is ready but contains no requests (dispatch=%s).",
      lifecycle_operation_label(plan.operation),
      dispatch_policy_label(plan.dispatch_policy));
  }

  const bool success = execute_lifecycle_plan_(plan);
  finalize_lifecycle_result_(plan, success);
  return success;
}

void CanHandBase::handle_precondition_failure_(const WritePlan & plan)
{
  if (!plan.reason.empty()) {
    RCLCPP_WARN_THROTTLE(
      logger(),
      throttle_clock(),
      1000,
      "Write plan rejected: %s",
      plan.reason.c_str());
    return;
  }

  RCLCPP_WARN_THROTTLE(
    logger(),
    throttle_clock(),
    1000,
    "Write plan rejected without explicit reason (block_reason=%s, dispatch=%s).",
    write_block_reason_label(plan.block_reason),
    dispatch_policy_label(plan.dispatch_policy));
}

void CanHandBase::handle_lifecycle_plan_failure_(const LifecyclePlan & plan)
{
  if (!plan.reason.empty()) {
    RCLCPP_WARN_THROTTLE(
      logger(),
      throttle_clock(),
      1000,
      "Lifecycle plan '%s' rejected: %s",
      lifecycle_operation_label(plan.operation),
      plan.reason.c_str());
    return;
  }

  RCLCPP_WARN_THROTTLE(
    logger(),
    throttle_clock(),
    1000,
    "Lifecycle plan '%s' rejected without explicit reason (dispatch=%s).",
    lifecycle_operation_label(plan.operation),
    dispatch_policy_label(plan.dispatch_policy));
}

WritePlan CanHandBase::build_write_plan_()
{
  WritePlan plan;
  const auto joint_cmd = joint_command_view();

  if (!joint_cmd.all_finite()) {
    plan.validity.all_finite = false;
    plan.invalid_command = true;
    plan.block_reason = WriteBlockReason::kInvalidCommand;
    plan.reason = "Skipping write: non-finite joint commands.";
    plan.validity.reason = plan.reason;
    return plan;
  }
  plan.desired_joint_command.capture(joint_cmd);

  if (!state_snapshot_.transport_healthy) {
    plan.return_error = true;
    plan.block_reason = WriteBlockReason::kTransportFault;
    plan.reason = "Skipping write: transport is not healthy.";
    plan.validity.reason = plan.reason;
    return plan;
  }

  if (state_snapshot_.lifecycle_busy) {
    plan.block_reason = WriteBlockReason::kLifecycleBusy;
    plan.reason = "Skipping write: lifecycle transition in progress.";
    plan.validity.reason = plan.reason;
    return plan;
  }

  if (!state_snapshot_.calibrated) {
    plan.not_calibrated = true;
    plan.block_reason = WriteBlockReason::kNotCalibrated;
    plan.reason = "Skipping write: hardware is not calibrated.";
    plan.validity.reason = plan.reason;
    return plan;
  }

  if (!state_snapshot_.model_ready) {
    plan.block_reason = WriteBlockReason::kModelNotReady;
    plan.reason = "Skipping write: hand model is not ready.";
    plan.validity.reason = plan.reason;
    return plan;
  }

  if (!state_snapshot_.has_fresh_rx) {
    plan.stale_state = true;
    plan.validity.stale_state = true;
    plan.block_reason = WriteBlockReason::kMissingFeedback;
    plan.reason = "Skipping write: actuator feedback is stale or missing.";
    plan.validity.reason = plan.reason;
    return plan;
  }

  plan.ready = true;
  build_ready_write_plan_(plan);
  return plan;
}

void CanHandBase::finalize_write_result_(const WritePlan & plan, bool success)
{
  last_write_result_ = CommandResult{};
  last_write_result_.sent = success;
  last_write_result_.transport_error = !success;
  last_write_result_.request_count = plan.request_count();
  last_write_result_.dispatch_policy = plan.dispatch_policy;

  if (should_commit_history(plan.command_history_policy, success)) {
    if (!plan.desired_joint_command.empty()) {
      joint_commands_.capture_previous_from(
        plan.desired_joint_command.position,
        plan.desired_joint_command.velocity,
        plan.desired_joint_command.effort);
      last_write_result_.command_history_committed = true;
    } else if (get_num_joints() > 0) {
      capture_joint_commands();
      last_write_result_.command_history_committed = true;
    }

    if (!plan.computed_actuator_command.empty()) {
      actuator_commands_.capture_previous_from(
        plan.computed_actuator_command.position,
        plan.computed_actuator_command.velocity,
        plan.computed_actuator_command.effort);
      last_write_result_.command_history_committed = true;
    } else if (get_num_actuators() > 0) {
      capture_actuator_commands();
      last_write_result_.command_history_committed = true;
    }
  }
}

void CanHandBase::finalize_lifecycle_result_(const LifecyclePlan & plan, bool success)
{
  last_lifecycle_result_ = CommandResult{};
  last_lifecycle_result_.sent = success;
  last_lifecycle_result_.transport_error = !success;
  last_lifecycle_result_.request_count = plan.request_count();
  last_lifecycle_result_.dispatch_policy = plan.dispatch_policy;
}

}  // namespace can_hardware_common::core
