#include <gtest/gtest.h>

#include <limits>
#include <utility>

#include "can_hardware_common/core/can_hand_base.hpp"
#include "can_hardware_common/core/command_result.hpp"
#include "can_hardware_common/core/command_validity_report.hpp"
#include "can_hardware_common/core/lifecycle_plan.hpp"
#include "can_hardware_common/core/state_snapshot.hpp"
#include "can_hardware_common/core/write_plan.hpp"

namespace can_hardware_common::core
{
namespace
{

class FakeHand final : public CanHandBase
{
public:
  FakeHand()
  {
    initialize_joint_buffers(2, 0.0);
    initialize_actuator_buffers(2, 0.0);
    snapshot_after_refresh.has_fresh_rx = true;
    snapshot_after_refresh.calibrated = true;
    snapshot_after_refresh.sensors_ok = true;
    snapshot_after_refresh.actuators_ready = true;
    snapshot_after_refresh.transport_healthy = true;
    snapshot_after_refresh.lifecycle_busy = false;
    snapshot_after_refresh.model_ready = true;
  }

  bool update_measurements_return_value = true;
  bool execute_write_return_value = true;
  bool execute_lifecycle_return_value = true;
  bool handle_precondition_called = false;
  int update_measurements_count = 0;
  int refresh_snapshot_count = 0;
  int execute_write_count = 0;
  int execute_lifecycle_count = 0;
  StateSnapshot snapshot_after_refresh;
  WritePlan last_handled_precondition_plan;

  WritePlan next_write_plan;
  LifecyclePlan next_enable_plan;
  LifecyclePlan next_disable_plan;
  LifecyclePlan next_zero_plan;

private:
  bool update_measurements_() override
  {
    ++update_measurements_count;
    return update_measurements_return_value;
  }

  void refresh_state_snapshot_() override
  {
    ++refresh_snapshot_count;
    state_snapshot_ = snapshot_after_refresh;
  }

  void build_ready_write_plan_(WritePlan & plan) override
  {
    plan = next_write_plan;
  }

  bool execute_write_plan_(const WritePlan &) override
  {
    ++execute_write_count;
    return execute_write_return_value;
  }

  LifecyclePlan build_lifecycle_plan_(LifecycleOperation operation) override
  {
    switch (operation) {
      case LifecycleOperation::kEnable:
        return next_enable_plan;
      case LifecycleOperation::kDisable:
        return next_disable_plan;
      case LifecycleOperation::kZero:
        return next_zero_plan;
    }

    return LifecyclePlan{};
  }

  bool execute_lifecycle_plan_(const LifecyclePlan &) override
  {
    ++execute_lifecycle_count;
    return execute_lifecycle_return_value;
  }

  void handle_precondition_failure_(const WritePlan & plan) override
  {
    handle_precondition_called = true;
    last_handled_precondition_plan = plan;
  }
};

TEST(CommandValidityReportTest, OkReflectsDynamicFlags)
{
  CommandValidityReport report;
  EXPECT_TRUE(report.ok());

  report.stale_state = true;
  EXPECT_FALSE(report.ok());

  report.stale_state = false;
  report.mode_valid = false;
  EXPECT_FALSE(report.ok());
}

TEST(StateSnapshotTest, ResizeAllocatesJointAndActuatorSpaces)
{
  StateSnapshot snapshot;
  snapshot.resize(8, 6);

  EXPECT_EQ(snapshot.joint_position.size(), 8);
  EXPECT_EQ(snapshot.joint_velocity.size(), 8);
  EXPECT_EQ(snapshot.joint_effort.size(), 8);
  EXPECT_EQ(snapshot.actuator_states.size(), 6U);
  EXPECT_FALSE(snapshot.has_fresh_rx);
  EXPECT_TRUE(snapshot.sensors_ok);
  EXPECT_EQ(snapshot.sensor_status.expected_count, 0U);
  EXPECT_TRUE(snapshot.sensor_status.ok());
}

TEST(WritePlanTest, RequestCountIncludesDirectAndScheduledRequests)
{
  WritePlan plan;
  plan.direct_frames.push_back(TPCANMsg{});
  plan.direct_frames.push_back(TPCANMsg{});
  plan.scheduled_requests.push_back(can_hardware_common::CommandRequest{});

  EXPECT_EQ(plan.request_count(), 3U);
  EXPECT_EQ(plan.dispatch_policy, DispatchPolicy::kDirectFrames);
  EXPECT_EQ(plan.command_history_policy, CommandHistoryPolicy::kOnSuccess);
}

TEST(LifecyclePlanTest, RequestCountIncludesDirectAndScheduledRequests)
{
  LifecyclePlan plan;
  plan.direct_frames.push_back(TPCANMsg{});
  plan.scheduled_requests.push_back(can_hardware_common::CommandRequest{});
  plan.scheduled_requests.push_back(can_hardware_common::CommandRequest{});

  EXPECT_EQ(plan.request_count(), 3U);
}

TEST(CommandResultTest, DefaultsStartFalseAndZero)
{
  CommandResult result;
  EXPECT_FALSE(result.sent);
  EXPECT_FALSE(result.confirmed);
  EXPECT_FALSE(result.rejected);
  EXPECT_FALSE(result.transport_error);
  EXPECT_FALSE(result.timed_out);
  EXPECT_FALSE(result.command_history_committed);
  EXPECT_EQ(result.request_count, 0U);
  EXPECT_EQ(result.dispatch_policy, DispatchPolicy::kDirectFrames);
}

TEST(CanHandBaseTest, ReadStopsBeforeRefreshWhenMeasurementUpdateFails)
{
  FakeHand hand;
  hand.update_measurements_return_value = false;

  EXPECT_FALSE(hand.read());
  EXPECT_EQ(hand.update_measurements_count, 1);
  EXPECT_EQ(hand.refresh_snapshot_count, 0);
}

TEST(CanHandBaseTest, ReadRefreshesSnapshotAfterMeasurementUpdate)
{
  FakeHand hand;

  EXPECT_TRUE(hand.read());
  EXPECT_EQ(hand.update_measurements_count, 1);
  EXPECT_EQ(hand.refresh_snapshot_count, 1);
}

TEST(CanHandBaseTest, WriteCallsPreconditionHandlerWhenPlanIsNotReady)
{
  FakeHand hand;
  hand.next_write_plan.ready = false;
  hand.next_write_plan.return_error = false;

  EXPECT_TRUE(hand.write());
  EXPECT_TRUE(hand.handle_precondition_called);
  EXPECT_EQ(hand.refresh_snapshot_count, 1);
  EXPECT_EQ(hand.execute_write_count, 0);
}

TEST(CanHandBaseTest, WritePollsMeasurementsBeforeRefreshingSnapshot)
{
  FakeHand hand;
  hand.next_write_plan.ready = false;
  hand.next_write_plan.return_error = false;

  EXPECT_TRUE(hand.write());
  EXPECT_EQ(hand.update_measurements_count, 1);
  EXPECT_EQ(hand.refresh_snapshot_count, 1);
}

TEST(CanHandBaseTest, WriteExecutesReadyPlan)
{
  FakeHand hand;
  hand.initialize_joint_buffers(2, 0.0);
  hand.initialize_actuator_buffers(2, 0.0);
  hand.joint_commands().position_at(0) = 1.2;
  hand.joint_commands().velocity_at(0) = 0.3;
  hand.joint_commands().effort_at(0) = 0.7;
  hand.actuator_commands().position_at(0) = 2.4;
  hand.actuator_commands().velocity_at(0) = 0.6;
  hand.actuator_commands().effort_at(0) = 1.4;
  hand.next_write_plan.ready = true;
  hand.next_write_plan.desired_joint_command.capture(hand.joint_command_view());
  hand.next_write_plan.computed_actuator_command.capture(hand.actuator_command_view());

  EXPECT_TRUE(hand.write());
  EXPECT_EQ(hand.execute_write_count, 1);
  EXPECT_TRUE(hand.last_write_result().command_history_committed);
  ASSERT_TRUE(hand.has_previous_joint_command());
  ASSERT_TRUE(hand.has_previous_actuator_command());
  EXPECT_DOUBLE_EQ(hand.previous_joint_command_view().position(0), 1.2);
  EXPECT_DOUBLE_EQ(hand.previous_actuator_command_view().position(0), 2.4);
}

TEST(CanHandBaseTest, WriteBlocksNonFiniteJointCommandInCore)
{
  FakeHand hand;
  hand.initialize_joint_buffers(1, 0.0);
  hand.joint_commands().position_at(0) = std::numeric_limits<double>::quiet_NaN();

  EXPECT_TRUE(hand.write());
  EXPECT_TRUE(hand.handle_precondition_called);
  EXPECT_EQ(hand.last_handled_precondition_plan.block_reason, WriteBlockReason::kInvalidCommand);
  EXPECT_EQ(hand.execute_write_count, 0);
}

TEST(CanHandBaseTest, WriteBlocksOnMissingFeedbackInCore)
{
  FakeHand hand;
  hand.snapshot_after_refresh.has_fresh_rx = false;

  EXPECT_TRUE(hand.write());
  EXPECT_TRUE(hand.handle_precondition_called);
  EXPECT_EQ(hand.last_handled_precondition_plan.block_reason, WriteBlockReason::kMissingFeedback);
  EXPECT_EQ(hand.execute_write_count, 0);
}

TEST(CanHandBaseTest, WriteBlocksOnTransportFaultInCore)
{
  FakeHand hand;
  hand.snapshot_after_refresh.transport_healthy = false;

  EXPECT_FALSE(hand.write());
  EXPECT_TRUE(hand.handle_precondition_called);
  EXPECT_EQ(hand.last_handled_precondition_plan.block_reason, WriteBlockReason::kTransportFault);
  EXPECT_EQ(hand.execute_write_count, 0);
}

TEST(CanHandBaseTest, WriteBlocksOnLifecycleBusyInCore)
{
  FakeHand hand;
  hand.snapshot_after_refresh.lifecycle_busy = true;

  EXPECT_TRUE(hand.write());
  EXPECT_TRUE(hand.handle_precondition_called);
  EXPECT_EQ(hand.last_handled_precondition_plan.block_reason, WriteBlockReason::kLifecycleBusy);
  EXPECT_EQ(hand.execute_write_count, 0);
}

TEST(CanHandBaseTest, WriteBlocksOnMissingCalibrationInCore)
{
  FakeHand hand;
  hand.snapshot_after_refresh.calibrated = false;

  EXPECT_TRUE(hand.write());
  EXPECT_TRUE(hand.handle_precondition_called);
  EXPECT_EQ(hand.last_handled_precondition_plan.block_reason, WriteBlockReason::kNotCalibrated);
  EXPECT_EQ(hand.execute_write_count, 0);
}

TEST(CanHandBaseTest, WriteBlocksOnModelNotReadyInCore)
{
  FakeHand hand;
  hand.snapshot_after_refresh.model_ready = false;

  EXPECT_TRUE(hand.write());
  EXPECT_TRUE(hand.handle_precondition_called);
  EXPECT_EQ(hand.last_handled_precondition_plan.block_reason, WriteBlockReason::kModelNotReady);
  EXPECT_EQ(hand.execute_write_count, 0);
}

TEST(CanHandBaseTest, EnableCanChainZeroPlanWhenRequested)
{
  FakeHand hand;
  hand.next_enable_plan.ready = true;
  hand.next_zero_plan.ready = true;

  EXPECT_TRUE(hand.enable(true));
  EXPECT_EQ(hand.execute_lifecycle_count, 2);
}

TEST(CanHandBaseTest, DisableAndZeroUseLifecycleExecutionPath)
{
  FakeHand hand;
  hand.next_disable_plan.ready = true;
  hand.next_zero_plan.ready = true;

  EXPECT_TRUE(hand.disable());
  EXPECT_TRUE(hand.zero());
  EXPECT_EQ(hand.execute_lifecycle_count, 2);
}

}  // namespace
}  // namespace can_hardware_common::core
