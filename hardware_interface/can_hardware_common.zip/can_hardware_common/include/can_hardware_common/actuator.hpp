#ifndef CAN_HARDWARE_COMMON__ACTUATOR_HPP_
#define CAN_HARDWARE_COMMON__ACTUATOR_HPP_

#include "can_hardware_common/scheduler/command_request.hpp"
#include "can_hardware_common/types/actuator_types.hpp"

#endif  // CAN_HARDWARE_COMMON__ACTUATOR_HPP_
