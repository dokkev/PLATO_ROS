#ifndef CAN_HARDWARE_COMMON__CORE__CAN_HAND_BASE_HPP_
#define CAN_HARDWARE_COMMON__CORE__CAN_HAND_BASE_HPP_

#include <vector>

#include "can_hardware_common/core/can_hand_runtime_state.hpp"
#include "can_hardware_common/core/control_block_reason.hpp"
#include "can_hardware_common/core/lifecycle_result.hpp"
#include "can_hardware_common/core/lifecycle_session.hpp"
#include "can_hardware_common/core/send_policy.hpp"
#include "can_hardware_common/core/write_result.hpp"

namespace can_hardware_common::core
{

class CanHandBase
{
public:
  explicit CanHandBase(SendPolicy send_policy = {});
  virtual ~CanHandBase() = default;

  bool read();
  bool write();
  bool enable();
  bool disable();
  bool zero();

  const SendPolicy & send_policy() const { return send_policy_; }
  const CanHandRuntimeState & runtime_state() const { return runtime_state_; }
  const LifecycleSession & lifecycle_session() const { return lifecycle_session_; }
  const WriteResult & last_write_result() const { return last_write_result_; }
  const LifecycleResult & last_lifecycle_result() const { return last_lifecycle_result_; }

protected:
  using TimePoint = can_hardware_common::types::TimePoint;

  virtual bool poll_rx_() = 0;
  virtual void refresh_runtime_state_() = 0;
  virtual CommandValidationResult validate_control_command_() const = 0;
  virtual std::vector<TxFrame> build_control_tx_frames_() = 0;
  virtual std::vector<LifecycleStep> build_lifecycle_steps_(LifecycleOperation operation) = 0;
  virtual bool is_lifecycle_step_confirmed_(
    LifecycleOperation operation,
    std::size_t step_index) const = 0;
  virtual bool send_tx_frame_(const TxFrame & tx_frame) = 0;
  virtual bool send_command_request_(const CommandRequest & request);
  virtual TimePoint now_() const;
  virtual void wait_for_lifecycle_progress_();
  virtual void on_lifecycle_session_started_(LifecycleOperation operation, std::size_t total_steps);
  virtual void on_lifecycle_step_sent_(
    LifecycleOperation operation,
    std::size_t step_index,
    const LifecycleStep & step);
  virtual void on_lifecycle_step_confirmed_(
    LifecycleOperation operation,
    std::size_t step_index,
    const LifecycleStep & step);
  virtual void on_lifecycle_session_finished_(const LifecycleResult & result);

  bool can_send_control_now_() const;
  bool can_send_lifecycle_now_() const;
  bool run_lifecycle_operation_(LifecycleOperation operation);
  bool run_lifecycle_session_(
    LifecycleOperation operation,
    const std::vector<LifecycleStep> & steps);
  void initialize_lifecycle_session_(LifecycleOperation operation);
  bool send_current_lifecycle_step_(const std::vector<LifecycleStep> & steps);
  bool lifecycle_confirmation_timed_out_() const;
  void advance_lifecycle_step_(const std::vector<LifecycleStep> & steps);
  void fail_lifecycle_session_(const std::string & reason, bool timed_out = false);

  SendPolicy send_policy_{};
  CanHandRuntimeState runtime_state_{};
  LifecycleSession lifecycle_session_{};
  WriteResult last_write_result_{};
  LifecycleResult last_lifecycle_result_{};
};

}  // namespace can_hardware_common::core

#endif  // CAN_HARDWARE_COMMON__CORE__CAN_HAND_BASE_HPP_
