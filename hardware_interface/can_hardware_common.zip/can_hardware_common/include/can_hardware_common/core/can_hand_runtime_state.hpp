#ifndef CAN_HARDWARE_COMMON__CORE__CAN_HAND_RUNTIME_STATE_HPP_
#define CAN_HARDWARE_COMMON__CORE__CAN_HAND_RUNTIME_STATE_HPP_

#include "can_hardware_common/types/time_types.hpp"

namespace can_hardware_common::core
{

struct CanHandRuntimeState
{
  can_hardware_common::types::TimePoint last_control_tx_time{};
  can_hardware_common::types::TimePoint last_rx_time{};
  bool model_ready = false;
  bool lifecycle_active = false;
  bool transport_ok = true;
};

}  // namespace can_hardware_common::core

#endif  // CAN_HARDWARE_COMMON__CORE__CAN_HAND_RUNTIME_STATE_HPP_
