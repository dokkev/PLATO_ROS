#ifndef CAN_HARDWARE_COMMON__CORE__CONTROL_BLOCK_REASON_HPP_
#define CAN_HARDWARE_COMMON__CORE__CONTROL_BLOCK_REASON_HPP_

#include <string>

namespace can_hardware_common::core
{

enum class ControlBlockReason
{
  kNone,
  kInvalidCommand,
  kModelNotReady,
  kLifecycleActive,
  kPacingBlocked,
  kTransportFault,
};

struct CommandValidationResult
{
  bool ok = false;
  ControlBlockReason reason = ControlBlockReason::kNone;
  std::string detail;

  static CommandValidationResult allow()
  {
    CommandValidationResult result;
    result.ok = true;
    return result;
  }
};

}  // namespace can_hardware_common::core

#endif  // CAN_HARDWARE_COMMON__CORE__CONTROL_BLOCK_REASON_HPP_
