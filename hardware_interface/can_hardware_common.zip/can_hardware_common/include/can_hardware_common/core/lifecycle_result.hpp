#ifndef CAN_HARDWARE_COMMON__CORE__LIFECYCLE_RESULT_HPP_
#define CAN_HARDWARE_COMMON__CORE__LIFECYCLE_RESULT_HPP_

#include <cstddef>
#include <string>

#include "can_hardware_common/core/lifecycle_session.hpp"

namespace can_hardware_common::core
{

struct LifecycleResult
{
  LifecycleOperation operation = LifecycleOperation::kNone;
  bool success = false;
  bool timed_out = false;
  bool send_failed = false;
  bool confirmation_failed = false;
  std::size_t total_steps = 0;
  std::size_t completed_steps = 0;
  std::string detail;
};

}  // namespace can_hardware_common::core

#endif  // CAN_HARDWARE_COMMON__CORE__LIFECYCLE_RESULT_HPP_
