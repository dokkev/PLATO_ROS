#ifndef CAN_HARDWARE_COMMON__CORE__LIFECYCLE_SESSION_HPP_
#define CAN_HARDWARE_COMMON__CORE__LIFECYCLE_SESSION_HPP_

#include <cstddef>
#include <string>

#include "can_hardware_common/scheduler/command_request.hpp"
#include "can_hardware_common/types/can_frame_types.hpp"
#include "can_hardware_common/types/time_types.hpp"

namespace can_hardware_common::core
{

enum class LifecycleOperation
{
  kNone,
  kEnable,
  kDisable,
  kZero,
};

enum class LifecyclePhase
{
  kIdle,
  kReadyToSend,
  kWaitingConfirmation,
  kDone,
  kFailed,
};

enum class LifecycleStepKind
{
  kDirectTx,
  kScheduledRequest,
};

struct LifecycleStep
{
  LifecycleStepKind kind = LifecycleStepKind::kDirectTx;
  TxFrame tx_frame{};
  CommandRequest request{};
  bool requires_confirmation = true;
};

struct LifecycleSession
{
  LifecycleOperation operation = LifecycleOperation::kNone;
  LifecyclePhase phase = LifecyclePhase::kIdle;
  std::size_t step_index = 0;
  can_hardware_common::types::TimePoint start_time{};
  can_hardware_common::types::TimePoint last_tx_time{};
  can_hardware_common::types::TimePoint wait_start_time{};
  bool active = false;
  bool confirmed = false;
  std::string failure_reason;
};

}  // namespace can_hardware_common::core

#endif  // CAN_HARDWARE_COMMON__CORE__LIFECYCLE_SESSION_HPP_
