#ifndef CAN_HARDWARE_COMMON__CORE__SEND_POLICY_HPP_
#define CAN_HARDWARE_COMMON__CORE__SEND_POLICY_HPP_

#include <chrono>

namespace can_hardware_common::core
{

struct SendPolicy
{
  std::chrono::microseconds control_min_tx_gap{0};
  std::chrono::microseconds lifecycle_min_tx_gap{0};
  std::chrono::microseconds lifecycle_confirmation_timeout{5000};
  std::chrono::microseconds lifecycle_poll_interval{100};
};

}  // namespace can_hardware_common::core

#endif  // CAN_HARDWARE_COMMON__CORE__SEND_POLICY_HPP_
