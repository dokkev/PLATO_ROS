#ifndef CAN_HARDWARE_COMMON__CORE__WRITE_RESULT_HPP_
#define CAN_HARDWARE_COMMON__CORE__WRITE_RESULT_HPP_

#include <cstddef>
#include <string>

#include "can_hardware_common/core/control_block_reason.hpp"

namespace can_hardware_common::core
{

struct WriteResult
{
  bool sent = false;
  bool transport_failed = false;
  bool pacing_blocked = false;
  ControlBlockReason block_reason = ControlBlockReason::kNone;
  std::size_t tx_frame_count = 0;
  std::string detail;
};

}  // namespace can_hardware_common::core

#endif  // CAN_HARDWARE_COMMON__CORE__WRITE_RESULT_HPP_
