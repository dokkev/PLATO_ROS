#include "can_hardware_common/core/can_hand_base.hpp"

#include <thread>

namespace can_hardware_common::core
{

CanHandBase::CanHandBase(SendPolicy send_policy)
: send_policy_(send_policy)
{
}

bool CanHandBase::read()
{
  runtime_state_.transport_ok = poll_rx_();
  if (runtime_state_.transport_ok) {
    runtime_state_.last_rx_time = now_();
  }
  refresh_runtime_state_();
  runtime_state_.lifecycle_active = lifecycle_session_.active;
  return runtime_state_.transport_ok;
}

bool CanHandBase::write()
{
  last_write_result_ = WriteResult{};
  refresh_runtime_state_();

  if (lifecycle_session_.active || runtime_state_.lifecycle_active) {
    last_write_result_.block_reason = ControlBlockReason::kLifecycleActive;
    last_write_result_.detail = "control write blocked while lifecycle session is active";
    return true;
  }

  const CommandValidationResult validation = validate_control_command_();
  if (!validation.ok) {
    last_write_result_.block_reason = validation.reason;
    last_write_result_.detail = validation.detail;
    return validation.reason != ControlBlockReason::kTransportFault;
  }

  if (!can_send_control_now_()) {
    last_write_result_.block_reason = ControlBlockReason::kPacingBlocked;
    last_write_result_.pacing_blocked = true;
    last_write_result_.detail = "control write blocked by tx pacing policy";
    return true;
  }

  const std::vector<TxFrame> tx_frames = build_control_tx_frames_();
  last_write_result_.tx_frame_count = tx_frames.size();
  for (const auto & tx_frame : tx_frames) {
    if (!send_tx_frame_(tx_frame)) {
      last_write_result_.transport_failed = true;
      last_write_result_.block_reason = ControlBlockReason::kTransportFault;
      last_write_result_.detail = "control tx send failed";
      runtime_state_.transport_ok = false;
      return false;
    }
  }

  runtime_state_.last_control_tx_time = now_();
  last_write_result_.sent = true;
  return true;
}

bool CanHandBase::enable()
{
  return run_lifecycle_operation_(LifecycleOperation::kEnable);
}

bool CanHandBase::disable()
{
  return run_lifecycle_operation_(LifecycleOperation::kDisable);
}

bool CanHandBase::zero()
{
  return run_lifecycle_operation_(LifecycleOperation::kZero);
}

bool CanHandBase::send_command_request_(const CommandRequest & request)
{
  return send_tx_frame_(request.tx_frame);
}

CanHandBase::TimePoint CanHandBase::now_() const
{
  return can_hardware_common::types::SteadyClock::now();
}

void CanHandBase::wait_for_lifecycle_progress_()
{
  if (send_policy_.lifecycle_poll_interval.count() <= 0) {
    return;
  }
  std::this_thread::sleep_for(send_policy_.lifecycle_poll_interval);
}

void CanHandBase::on_lifecycle_session_started_(LifecycleOperation, std::size_t)
{
}

void CanHandBase::on_lifecycle_step_sent_(LifecycleOperation, std::size_t, const LifecycleStep &)
{
}

void CanHandBase::on_lifecycle_step_confirmed_(LifecycleOperation, std::size_t, const LifecycleStep &)
{
}

void CanHandBase::on_lifecycle_session_finished_(const LifecycleResult &)
{
}

bool CanHandBase::can_send_control_now_() const
{
  const TimePoint now = now_();
  if (runtime_state_.last_control_tx_time == TimePoint{}) {
    return true;
  }
  return (now - runtime_state_.last_control_tx_time) >= send_policy_.control_min_tx_gap;
}

bool CanHandBase::can_send_lifecycle_now_() const
{
  const TimePoint now = now_();
  if (lifecycle_session_.last_tx_time == TimePoint{}) {
    return true;
  }
  return (now - lifecycle_session_.last_tx_time) >= send_policy_.lifecycle_min_tx_gap;
}

bool CanHandBase::run_lifecycle_operation_(LifecycleOperation operation)
{
  const std::vector<LifecycleStep> steps = build_lifecycle_steps_(operation);
  return run_lifecycle_session_(operation, steps);
}

bool CanHandBase::run_lifecycle_session_(
  LifecycleOperation operation,
  const std::vector<LifecycleStep> & steps)
{
  last_lifecycle_result_ = LifecycleResult{};
  last_lifecycle_result_.operation = operation;
  last_lifecycle_result_.total_steps = steps.size();

  if (steps.empty()) {
    last_lifecycle_result_.success = true;
    on_lifecycle_session_finished_(last_lifecycle_result_);
    return true;
  }

  initialize_lifecycle_session_(operation);
  runtime_state_.lifecycle_active = true;
  on_lifecycle_session_started_(operation, steps.size());

  while (lifecycle_session_.active) {
    runtime_state_.transport_ok = poll_rx_();
    if (runtime_state_.transport_ok) {
      runtime_state_.last_rx_time = now_();
    } else {
      fail_lifecycle_session_("rx polling failed during lifecycle session");
      last_lifecycle_result_.send_failed = true;
      break;
    }

    refresh_runtime_state_();
    runtime_state_.lifecycle_active = lifecycle_session_.active;

    if (lifecycle_session_.phase == LifecyclePhase::kReadyToSend) {
      if (can_send_lifecycle_now_()) {
        if (!send_current_lifecycle_step_(steps)) {
          break;
        }
        continue;
      }
    } else if (lifecycle_session_.phase == LifecyclePhase::kWaitingConfirmation) {
      if (is_lifecycle_step_confirmed_(operation, lifecycle_session_.step_index)) {
        lifecycle_session_.confirmed = true;
        on_lifecycle_step_confirmed_(
          operation,
          lifecycle_session_.step_index,
          steps.at(lifecycle_session_.step_index));
        advance_lifecycle_step_(steps);
        continue;
      }

      if (lifecycle_confirmation_timed_out_()) {
        fail_lifecycle_session_("lifecycle confirmation timeout", true);
        break;
      }
    }

    wait_for_lifecycle_progress_();
  }

  runtime_state_.lifecycle_active = false;
  last_lifecycle_result_.completed_steps =
    lifecycle_session_.phase == LifecyclePhase::kDone ? steps.size() : lifecycle_session_.step_index;
  last_lifecycle_result_.success = lifecycle_session_.phase == LifecyclePhase::kDone;
  if (!last_lifecycle_result_.success && !lifecycle_session_.failure_reason.empty()) {
    last_lifecycle_result_.detail = lifecycle_session_.failure_reason;
  }

  on_lifecycle_session_finished_(last_lifecycle_result_);
  return last_lifecycle_result_.success;
}

void CanHandBase::initialize_lifecycle_session_(LifecycleOperation operation)
{
  lifecycle_session_ = LifecycleSession{};
  lifecycle_session_.operation = operation;
  lifecycle_session_.phase = LifecyclePhase::kReadyToSend;
  lifecycle_session_.start_time = now_();
  lifecycle_session_.active = true;
}

bool CanHandBase::send_current_lifecycle_step_(const std::vector<LifecycleStep> & steps)
{
  const LifecycleStep & step = steps.at(lifecycle_session_.step_index);

  bool send_ok = false;
  if (step.kind == LifecycleStepKind::kDirectTx) {
    send_ok = send_tx_frame_(step.tx_frame);
  } else {
    send_ok = send_command_request_(step.request);
  }

  if (!send_ok) {
    last_lifecycle_result_.send_failed = true;
    fail_lifecycle_session_("lifecycle send failed");
    return false;
  }

  lifecycle_session_.last_tx_time = now_();
  on_lifecycle_step_sent_(lifecycle_session_.operation, lifecycle_session_.step_index, step);

  if (step.requires_confirmation) {
    lifecycle_session_.phase = LifecyclePhase::kWaitingConfirmation;
    lifecycle_session_.wait_start_time = lifecycle_session_.last_tx_time;
    lifecycle_session_.confirmed = false;
    return true;
  }

  advance_lifecycle_step_(steps);
  return true;
}

bool CanHandBase::lifecycle_confirmation_timed_out_() const
{
  if (lifecycle_session_.wait_start_time == TimePoint{}) {
    return false;
  }

  return (now_() - lifecycle_session_.wait_start_time) >=
         send_policy_.lifecycle_confirmation_timeout;
}

void CanHandBase::advance_lifecycle_step_(const std::vector<LifecycleStep> & steps)
{
  ++lifecycle_session_.step_index;
  if (lifecycle_session_.step_index >= steps.size()) {
    lifecycle_session_.phase = LifecyclePhase::kDone;
    lifecycle_session_.active = false;
    return;
  }

  lifecycle_session_.phase = LifecyclePhase::kReadyToSend;
}

void CanHandBase::fail_lifecycle_session_(const std::string & reason, bool timed_out)
{
  lifecycle_session_.phase = LifecyclePhase::kFailed;
  lifecycle_session_.active = false;
  lifecycle_session_.failure_reason = reason;
  last_lifecycle_result_.timed_out = timed_out;
  last_lifecycle_result_.confirmation_failed = timed_out;
}

}  // namespace can_hardware_common::core
