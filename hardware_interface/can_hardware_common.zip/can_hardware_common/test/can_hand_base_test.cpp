#include <gtest/gtest.h>

#include <chrono>
#include <vector>

#include "can_hardware_common/core/can_hand_base.hpp"

namespace can_hardware_common::core
{
namespace
{

class FakeHand final : public CanHandBase
{
public:
  explicit FakeHand(SendPolicy send_policy = {})
  : CanHandBase(send_policy)
  {
    fake_now = TimePoint{} + std::chrono::microseconds(1);
  }

  bool poll_rx_result = true;
  mutable int confirmation_checks = 0;
  int poll_rx_count = 0;
  int refresh_count = 0;
  int send_tx_count = 0;
  int send_request_count = 0;
  int wait_count = 0;
  bool runtime_model_ready = true;
  bool runtime_lifecycle_active = false;
  bool next_send_ok = true;
  CommandValidationResult validation = CommandValidationResult::allow();
  std::vector<TxFrame> control_tx_frames;
  std::vector<LifecycleStep> lifecycle_steps;
  std::vector<bool> confirmed_steps;
  std::vector<TimePoint> send_times;
  std::chrono::microseconds wait_advance{100};
  TimePoint fake_now{};

private:
  bool poll_rx_() override
  {
    ++poll_rx_count;
    return poll_rx_result;
  }

  void refresh_runtime_state_() override
  {
    ++refresh_count;
    runtime_state_.model_ready = runtime_model_ready;
    runtime_state_.lifecycle_active = runtime_lifecycle_active || lifecycle_session_.active;
  }

  CommandValidationResult validate_control_command_() const override
  {
    return validation;
  }

  std::vector<TxFrame> build_control_tx_frames_() override
  {
    return control_tx_frames;
  }

  std::vector<LifecycleStep> build_lifecycle_steps_(LifecycleOperation) override
  {
    return lifecycle_steps;
  }

  bool is_lifecycle_step_confirmed_(LifecycleOperation, std::size_t step_index) const override
  {
    ++confirmation_checks;
    return step_index < confirmed_steps.size() && confirmed_steps[step_index];
  }

  bool send_tx_frame_(const TxFrame &) override
  {
    send_times.push_back(fake_now);
    ++send_tx_count;
    return next_send_ok;
  }

  bool send_command_request_(const CommandRequest & request) override
  {
    ++send_request_count;
    return send_tx_frame_(request.tx_frame);
  }

  TimePoint now_() const override
  {
    return fake_now;
  }

  void wait_for_lifecycle_progress_() override
  {
    ++wait_count;
    fake_now += wait_advance;
  }
};

TxFrame make_tx_frame(uint32_t can_id)
{
  TxFrame tx_frame{};
  tx_frame.ID = can_id;
  tx_frame.MSGTYPE = PCAN_MESSAGE_STANDARD;
  tx_frame.LEN = 1;
  tx_frame.DATA[0] = 0xAA;
  return tx_frame;
}

TEST(CanHandBaseTest, ControlWriteDoesNotRetryOnSendFailure)
{
  FakeHand hand;
  hand.control_tx_frames = {make_tx_frame(0x11)};
  hand.next_send_ok = false;

  EXPECT_FALSE(hand.write());
  EXPECT_EQ(hand.send_tx_count, 1);
  EXPECT_TRUE(hand.last_write_result().transport_failed);
}

TEST(CanHandBaseTest, ControlWriteRespectsControlTxGap)
{
  SendPolicy send_policy;
  send_policy.control_min_tx_gap = std::chrono::microseconds(1000);

  FakeHand hand(send_policy);
  hand.control_tx_frames = {make_tx_frame(0x11)};

  EXPECT_TRUE(hand.write());
  EXPECT_EQ(hand.send_tx_count, 1);

  EXPECT_TRUE(hand.write());
  EXPECT_EQ(hand.send_tx_count, 1);
  EXPECT_TRUE(hand.last_write_result().pacing_blocked);
  EXPECT_EQ(hand.last_write_result().block_reason, ControlBlockReason::kPacingBlocked);
}

TEST(CanHandBaseTest, ControlWriteIsBlockedWhenLifecycleIsActive)
{
  FakeHand hand;
  hand.runtime_lifecycle_active = true;
  hand.control_tx_frames = {make_tx_frame(0x11)};

  EXPECT_TRUE(hand.write());
  EXPECT_EQ(hand.send_tx_count, 0);
  EXPECT_EQ(hand.last_write_result().block_reason, ControlBlockReason::kLifecycleActive);
}

TEST(CanHandBaseTest, InvalidControlCommandIsRejected)
{
  FakeHand hand;
  hand.validation.ok = false;
  hand.validation.reason = ControlBlockReason::kInvalidCommand;
  hand.validation.detail = "command vector contained non-finite values";
  hand.control_tx_frames = {make_tx_frame(0x11)};

  EXPECT_TRUE(hand.write());
  EXPECT_EQ(hand.send_tx_count, 0);
  EXPECT_EQ(hand.last_write_result().block_reason, ControlBlockReason::kInvalidCommand);
}

TEST(CanHandBaseTest, ControlPathDoesNotWaitForConfirmation)
{
  FakeHand hand;
  hand.control_tx_frames = {make_tx_frame(0x11)};

  EXPECT_TRUE(hand.write());
  EXPECT_EQ(hand.wait_count, 0);
  EXPECT_EQ(hand.confirmation_checks, 0);
}

TEST(CanHandBaseTest, LifecycleSessionSendsOneStepAtATime)
{
  SendPolicy send_policy;
  send_policy.lifecycle_poll_interval = std::chrono::microseconds(100);

  FakeHand hand(send_policy);
  LifecycleStep step_a;
  step_a.kind = LifecycleStepKind::kDirectTx;
  step_a.tx_frame = make_tx_frame(0x21);
  LifecycleStep step_b = step_a;
  step_b.tx_frame = make_tx_frame(0x22);
  hand.lifecycle_steps = {step_a, step_b};
  hand.confirmed_steps = {false, true};

  EXPECT_FALSE(hand.enable());
  EXPECT_EQ(hand.send_tx_count, 1);
  EXPECT_TRUE(hand.last_lifecycle_result().timed_out);
}

TEST(CanHandBaseTest, LifecycleSessionRespectsLifecycleTxGap)
{
  SendPolicy send_policy;
  send_policy.lifecycle_min_tx_gap = std::chrono::microseconds(500);
  send_policy.lifecycle_confirmation_timeout = std::chrono::microseconds(2000);
  send_policy.lifecycle_poll_interval = std::chrono::microseconds(100);

  FakeHand hand(send_policy);
  LifecycleStep step_a;
  step_a.tx_frame = make_tx_frame(0x21);
  LifecycleStep step_b;
  step_b.tx_frame = make_tx_frame(0x22);
  hand.lifecycle_steps = {step_a, step_b};
  hand.confirmed_steps = {true, true};

  EXPECT_TRUE(hand.enable());
  ASSERT_EQ(hand.send_times.size(), 2U);
  EXPECT_GE(
    std::chrono::duration_cast<std::chrono::microseconds>(hand.send_times[1] - hand.send_times[0]).count(),
    500);
}

TEST(CanHandBaseTest, LifecycleSessionWaitsForConfirmationBeforeAdvancing)
{
  SendPolicy send_policy;
  send_policy.lifecycle_confirmation_timeout = std::chrono::microseconds(1000);
  send_policy.lifecycle_poll_interval = std::chrono::microseconds(100);

  FakeHand hand(send_policy);
  LifecycleStep step_a;
  step_a.tx_frame = make_tx_frame(0x21);
  LifecycleStep step_b;
  step_b.tx_frame = make_tx_frame(0x22);
  hand.lifecycle_steps = {step_a, step_b};
  hand.confirmed_steps = {false, true};

  EXPECT_FALSE(hand.enable());
  EXPECT_EQ(hand.send_tx_count, 1);
  EXPECT_GT(hand.confirmation_checks, 0);
}

TEST(CanHandBaseTest, LifecycleSessionFailsOnConfirmationTimeout)
{
  SendPolicy send_policy;
  send_policy.lifecycle_confirmation_timeout = std::chrono::microseconds(300);
  send_policy.lifecycle_poll_interval = std::chrono::microseconds(100);

  FakeHand hand(send_policy);
  LifecycleStep step;
  step.tx_frame = make_tx_frame(0x21);
  hand.lifecycle_steps = {step};
  hand.confirmed_steps = {false};

  EXPECT_FALSE(hand.enable());
  EXPECT_TRUE(hand.last_lifecycle_result().timed_out);
  EXPECT_FALSE(hand.last_lifecycle_result().success);
}

TEST(CanHandBaseTest, LifecycleSessionDoesNotRequireRetryToFunction)
{
  SendPolicy send_policy;
  send_policy.lifecycle_confirmation_timeout = std::chrono::microseconds(1000);
  send_policy.lifecycle_poll_interval = std::chrono::microseconds(100);

  FakeHand hand(send_policy);
  LifecycleStep step_a;
  step_a.tx_frame = make_tx_frame(0x21);
  LifecycleStep step_b;
  step_b.tx_frame = make_tx_frame(0x22);
  hand.lifecycle_steps = {step_a, step_b};
  hand.confirmed_steps = {true, true};

  EXPECT_TRUE(hand.enable());
  EXPECT_EQ(hand.send_tx_count, 2);
}

TEST(CanHandBaseTest, LifecycleSessionCompletesWhenAllStepsAreConfirmed)
{
  SendPolicy send_policy;
  send_policy.lifecycle_confirmation_timeout = std::chrono::microseconds(1000);
  send_policy.lifecycle_poll_interval = std::chrono::microseconds(100);

  FakeHand hand(send_policy);
  LifecycleStep step_a;
  step_a.tx_frame = make_tx_frame(0x21);
  LifecycleStep step_b;
  step_b.tx_frame = make_tx_frame(0x22);
  hand.lifecycle_steps = {step_a, step_b};
  hand.confirmed_steps = {true, true};

  EXPECT_TRUE(hand.enable());
  EXPECT_TRUE(hand.last_lifecycle_result().success);
  EXPECT_EQ(hand.last_lifecycle_result().completed_steps, 2U);
}

}  // namespace
}  // namespace can_hardware_common::core
