# MPPI Direction: GraspState-Predictive Contact Control

## 1. Core Idea

This package implements a **GraspState-predictive MPPI controller** for tactile contact manipulation.

The controller is **not** designed to predict exact future contact force.
Instead, it samples possible future grasp outcomes under contact uncertainty and chooses actions that keep the grasp stable.

The central question is:

```txt
Given this joint acceleration action,
will the robot maintain, lose, or discover tactile contact support?
```

More specifically:

```txt
Will more tactile hemispheres become active?
Will currently active hemispheres remain active?
Will the contact state become more stable or more fragile?
Will shear, rotation, or contact loss risk increase?
```

The key quantity is therefore not future force magnitude, but the **contact Jacobian of each tactile hemisphere**.

---

## 2. State Definition

The top-level rollout state is `GraspState`.

```txt
GraspState = RobotState + vector<TactileState>
```

Mathematically:

```txt
G_k = (R_k, T^0_k, T^1_k, ..., T^{N-1}_k)
```

where:

```txt
R_k   = RobotState
T^s_k = TactileState for tactile sensor s
```

Each `TactileState` represents one tactile sensor.

```txt
TactileState
  ├── sensor-level aggregate signals
  │     ├── contact_state
  │     ├── total_force_n
  │     ├── shear_displacement_m
  │     ├── rotational_shear_rad
  │     └── slip / confidence scores
  │
  └── vector<HemisphereState>
        ├── hemisphere_index
        ├── contact
        ├── cop_sensor_m
        ├── normal_force_n
        └── confidence
```

A `HemisphereState` is the MPPI-level tactile reasoning unit.
Raw tactile nodes are considered a lower-level sensor implementation detail and are not directly used by the MPPI rollout.

---

## 3. RobotState Semantics

`RobotState` is intentionally MPPI-agnostic.

```cpp
struct RobotState {
  Eigen::VectorXd q;
  Eigen::VectorXd qdot;
  Eigen::VectorXd tau;
};
```

The meaning of `tau` depends on context.

For real robot feedback:

```txt
tau = accepted current torque
```

This may include motor-current-based torque measurement, embedded feedback effects, contact reaction, filtering, and unmodeled dynamics.

For MPPI rollout:

```txt
tau = model torque predicted by RNEA
```

In rollout, `tau` is used as a model effort / feasibility proxy, not as a final torque command.

Do not interpret rollout `RobotState::tau` as:

```txt
tau_cmd
tau_ff_cmd
tau_fb_cmd
tau_meas
tau_applied
```

Those names belong to command, measurement, or applied-torque layers.

---

## 4. MPPI Action

The MPPI action is desired joint acceleration:

```txt
u_k = qddot_sol,k
```

The sampled action sequence is:

```txt
U = (qddot_sol,0, qddot_sol,1, ..., qddot_sol,H-1)
```

`qddot_sol` is treated as the solver output selected by MPPI.

---

## 5. Robot Rollout

The robot rollout assumes ideal tracking of the sampled acceleration command.

```txt
qdot_{k+1} = qdot_k + qddot_sol,k * dt

q_{k+1} = integrate(q_k, qdot_{k+1} * dt)

tau_k = RNEA(q_k, qdot_k, qddot_sol,k)
```

The rollout does not simulate the embedded driver impedance controller.

The embedded driver may later apply:

```txt
tau_driver_internal =
    tau_cmd
  + kp * (q_cmd - q_meas)
  + kd * (qdot_cmd - qdot_meas)
```

But this is not part of the MPPI rollout dynamics.

---

## 6. Tactile Rollout

The tactile rollout predicts how each tactile sensor state evolves under the candidate robot motion.

For each tactile sensor:

```txt
T^s_{k+1} = f_T(T^s_k, R_k, R_{k+1}, qddot_sol,k)
```

The important transition is the active hemisphere set:

```txt
A^s_k = { i | hemisphere_i.contact == true }
```

The future active set is conceptually:

```txt
A^s_{k+1} = (A^s_k - lost hemispheres) ∪ newly activated hemispheres
```

This means the rollout should eventually reason about:

```txt
survival:
  an active hemisphere remains in contact

loss:
  an active hemisphere loses contact

birth / discovery:
  an inactive hemisphere becomes active
```

The current implementation may begin with a simple kinematic transition and conservative contact preservation model.
The long-term goal is to make contact birth/loss depend on per-hemisphere contact kinematics.

---

## 7. Contact Jacobian as the Core Signal

The central geometric question is:

```txt
Does this action move inactive hemispheres toward contact,
and active hemispheres away from contact loss?
```

For each hemisphere `i`, Pinocchio provides a contact point Jacobian:

```txt
v_i = J_i(q) qdot
```

The normal component is:

```txt
v_i^n = n_i(q)^T J_i(q) qdot
```

A candidate action changes joint velocity:

```txt
qdot_{k+1} = qdot_k + qddot_sol,k * dt
```

Therefore the rollout can evaluate whether a hemisphere is moving toward or away from the local contact direction.

This is more important than predicting exact force.

The MPPI cost should prefer actions that:

```txt
increase useful active hemisphere support
maintain existing contact
avoid unloading active hemispheres
avoid excessive shear or rotational slip
avoid torque/action limits
```

---

## 8. Pinocchio Contact Kinematics

We use **one Pinocchio frame per tactile sensor**, not one frame per hemisphere.

Hemisphere geometry is stored separately from `TactileState`.

```txt
TactileState:
  what is measured or predicted

TactileSensorGeometry:
  where hemispheres are in the sensor frame

Pinocchio:
  how those points move with q and qdot
```

A hemisphere contact point is computed from the tactile sensor frame and local hemisphere point.

```txt
p_i^W(q) = p_S^W(q) + R_S^W(q) r_i^S
```

The point Jacobian is derived from the sensor frame spatial Jacobian.

```txt
J_i^c(q) = J_S^v(q) - [R_S^W r_i^S]_x J_S^ω(q)
```

The normal Jacobian is:

```txt
J_i^n(q) = n_i^W(q)^T J_i^c(q)
```

This allows MPPI to connect candidate joint acceleration to local contact motion.

---

## 9. Residual Force Projection

Residual torque projection is currently **not the primary rollout mechanism**.

A residual is defined only from real observed robot state:

```txt
tau_residual = tau_observed - RNEA(q_observed, qdot_observed, qddot_base)
```

It is a noisy evidence signal, not ground-truth contact force.

It may contain:

```txt
contact reaction
embedded feedback torque
friction
model error
sensor noise
unmodeled dynamics
```

Therefore residual should be used later as **observation-time GraspState correction**, not as the main horizon dynamics.

Current policy:

```txt
Residual projection is optional and may be disabled.

The initial rollout should work without residual force projection.
```

Future policy:

```txt
If exactly one tactile sensor is active:
  residual projection may be used as a local evidence signal.

If multiple tactile sensors are active:
  do not project the same residual separately into each sensor.
  A future multi-sensor solver should solve all active hemispheres jointly.
```

Correct future equation:

```txt
tau_residual ≈ Σ_s Σ_i J_{s,i}^T f_{s,i}
```

Until that joint solve exists, multi-sensor residual projection should be skipped.

---

## 10. Disturbance-Sampled GraspState MPPI

The controller should be understood as a disturbance-sampled grasp controller.

The rollout equation is:

```txt
G_{k+1}^{(i)} = f_G(G_k^{(i)}, u_k^{(i)}, w_k^{(i)})
```

where:

```txt
u_k = qddot_sol,k
w_k = sampled contact / tactile disturbance
```

Possible tactile disturbances include:

```txt
contact hemisphere loss
new hemisphere contact birth
shear displacement perturbation
rotational slip perturbation
normal force fluctuation
object pose drift
contact confidence decay
```

The cost estimates robustness over sampled future outcomes:

```txt
J(U) = E_W [ terminal_cost(G_H) + Σ stage_cost(G_k, u_k) ]
```

MPPI approximates this expectation through sampled rollouts.

The controller does not ask:

```txt
What exact force will occur in the future?
```

It asks:

```txt
Under plausible future contact disturbances,
which action keeps the GraspState stable?
```

---

## 11. Cost Direction

The cost should evaluate GraspState quality.

Useful cost terms include:

```txt
robot/action costs:
  qddot magnitude
  qdot limit
  tau effort / torque limit
  action smoothness

tactile costs:
  contact loss
  insufficient active hemispheres
  insufficient active tactile sensors
  excessive shear displacement
  excessive rotational shear
  low tactile confidence
  unstable contact transition

multi-sensor costs:
  too few active tactile sensors
  unbalanced contact support
  asymmetric contact loss
```

The cost should not depend on exact future force prediction.

---

## 12. Command Layer Boundary

The rollout does not directly define the final driver command.

The MPPI output is the first selected acceleration:

```txt
qddot_sol,0
```

A separate command builder converts this into driver command values.

```txt
qddot_sol
  -> integrate and clamp
  -> q_cmd, qdot_cmd

qddot_sol
  -> inverse dynamics
  -> tau_ff_cmd

optional host-side feedback:
  tau_fb_cmd = kp_fb * (q_cmd - q)
             + kd_fb * (qdot_cmd - qdot)

final driver torque:
  tau_cmd = tau_ff_cmd + tau_fb_cmd
```

The final driver packet contains:

```txt
q_cmd
qdot_cmd
tau_cmd
kp
kd
```

Here:

```txt
kp, kd       = driver-local impedance gains
kp_fb, kd_fb = host-side feedback gains
```

Do not mix these two gain layers.

---

## 13. Current Implementation Priorities

The current priority is to stabilize the architecture:

```txt
1. GraspState = RobotState + vector<TactileState>
2. TactileState = sensor aggregate + vector<HemisphereState>
3. MPPI action = qddot_sol
4. Robot rollout = ideal q/qdot integration + RNEA tau
5. Tactile rollout = hemisphere contact topology transition
6. Contact kinematics = per-hemisphere Jacobian from sensor frame
7. Residual projection = disabled or observation-time correction only
8. Command builder = separate from rollout
```

Do not add contact birth prediction, object pose tracking, or multi-sensor residual force solving until the above architecture is stable.

---

## 14. Non-Goals

This controller is not:

```txt
a full rigid-body contact simulator
an exact future contact force predictor
an object pose tracker
a residual-force estimator as the main controller
a driver impedance simulator
```

It is:

```txt
a GraspState-predictive MPPI controller
that samples possible future tactile/contact outcomes
and chooses actions that preserve or improve grasp stability.
```
