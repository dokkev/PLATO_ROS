# mppi_core

`mppi_core` is a ROS-free C++ package for contact-local MPPI grasp planning.
It solves a joint acceleration action, predicts a modular tactile-sensor
`GraspState` rollout, evaluates grasp costs, and outputs a low-level robot
command packet.

Main runtime pieces:

- `mppi_core::MPPIOptimizer`
- `mppi_core::GraspStateRolloutModel`
- `mppi_core::GraspState`
- `mppi_core::RobotState`
- `mppi_core::TactileState`
- `mppi_core::GraspObservation`
- `mppi_core::GraspStabilityCost`
- `mppi_core::RobotCommand`

Public headers are organized by responsibility under `state/`, `rollout/`,
`robot/`, `tactile/`, `contact/`, `costs/`, `config/`, and `core/`.

## Runtime Contract

The MPPI action is the solver acceleration `qddot_sol`. Its dimension is `nv`;
units are `rad/s^2` for revolute joints and `m/s^2` for prismatic joints. It is
not a command field.

The top-level rollout target is always `GraspState`:

```text
GraspState = RobotState + vector<TactileState>
```

Each robot rollout step assumes ideal reference tracking:

```text
qdot[k + 1] = qdot[k] + qddot_sol[k] * dt
q[k + 1]    = integrate(q[k], qdot[k + 1] * dt)
tau[k + 1]  = rnea(q[k], qdot[k], qddot_sol[k])
```

If a valid Pinocchio model/data context is unavailable, `tau` falls back to a
deterministic zero vector. The command builder computes model feedforward
torque from the accepted current robot state and the selected solver
acceleration:

```text
tau_ff_cmd = rnea(q, qdot, qddot_sol)
tau_cmd    = tau_ff_cmd
```

The embedded low-level driver may then apply its local impedance law:

```text
tau_driver = tau_cmd
           + kp * (q_cmd - q_meas)
           + kd * (qdot_cmd - qdot_meas)
```

The embedded PD feedback torque is not part of MPPI prediction.

## State Separation

`GraspObservation` contains measured inputs:

- `q_meas`
- `qdot_meas`
- `tau_meas`
- `q_ref_current`
- `qdot_ref_current`
- `tactile_meas`
- `robot_system`
- `tactile_contexts`

`RobotState` contains context-owned robot state:

- `q`
- `qdot`
- `tau`

`qddot_sol` is the MPPI action and is not stored in `RobotState` or
`RobotCommand`.

`TactileState` describes one tactile sensor. It contains sensor-level aggregate
fields such as `total_force_n`, shear displacement, rotational shear, slip
scores, confidence, and a dense fixed list of `HemisphereState` entries.
Inactive hemispheres stay in the list with `contact == false` so future contact
birth can be represented as `false -> true`.

The rollout predicts future `GraspState`: ideal/reference robot state plus
predicted tactile/contact-mode state. It does not claim exact future contact
force prediction.

## Tactile Transition

The current tactile transition is deterministic and contact-kinematic. It uses
per-hemisphere motion and contact Jacobians to update contact topology,
contact-point motion, shear/rotation features, confidence, and aggregate fields.
It does not use measured-torque residual projection inside MPPI horizon
dynamics.

Residual/contact-force projection helpers remain separate utilities for later
observation-time correction experiments.

`MPPIOptimizer` is rollout-model agnostic. The caller should gate no-contact
observations before entering contact-local MPPI. If every sampled rollout is
invalid, the optimizer resets the nominal action sequence and returns a
zero-acceleration hold command.

## Example

```cpp
mppi_core::MPPIConfig mppi_config;
mppi_core::GraspStateRolloutConfig rollout_config;

auto model = std::make_shared<mppi_core::GraspStateRolloutModel>(
    joint_dim, rollout_config);
auto cost = std::make_shared<mppi_core::GraspStabilityCost>(
    mppi_core::GraspStabilityCostConfig{});

mppi_core::MPPIOptimizer optimizer;
optimizer.Initialize(mppi_config, model, cost);

mppi_core::GraspObservation obs;
obs.q_meas = q_meas;
obs.qdot_meas = qdot_meas;
obs.tau_meas = tau_meas;
obs.q_ref_current = q_ref_current;
obs.qdot_ref_current = qdot_ref_current;
obs.tactile_meas = tactile_sensors;
obs.robot_system = &robot_system;
obs.tactile_contexts = tactile_contexts;

const mppi_core::RobotCommand command = optimizer.Update(obs);
```

## Config

Sampling budget, acceleration action bounds, and command gains live in
`config/mppi.yaml`.

Contact-local costs live in `config/grasp.yaml`. Hemisphere-based config names
are preferred, for example:

```yaml
grasp:
  hemisphere_contact:
    enabled: true
    target_active_hemisphere_count: 6
    weight: 2.0
```

More detail:

- `docs/grasp_state_mppi.md`
- `docs/file_structure.md`
