// Copyright 2026
//
// Licensed under the Apache License, Version 2.0.

#pragma once

#include <Eigen/Core>

#include <cstddef>

#include "mppi_core/rollout/rollout_model.hpp"
#include "mppi_core/state/grasp_state.hpp"

namespace mppi_core {

struct ObjectContactSupportEvaluatorConfig {
  bool enabled{true};

  std::size_t max_object_samples{16};
  std::size_t min_active_tactile_sensors{2};
  std::size_t min_active_hemisphere_total{2};

  double contact_birth_margin_m{0.001};
  double contact_loss_margin_m{0.003};
  double contact_stiffness_n_per_m{500.0};
  double max_predicted_normal_force_n{10.0};
  double min_predicted_contact_force_n{0.01};
  double max_predicted_force_per_sensor_n{5.0};

  double contact_loss_weight{200.0};
  double support_weight{20.0};
  double edge_weight{10.0};
  double predicted_force_high_weight{5.0};
  double target_edge_margin_m{0.001};

  bool use_particle_weights{true};
};

struct ObjectContactSupportEvaluation {
  bool valid{false};

  std::size_t object_sample_count{0};
  std::size_t geometry_query_count{0};

  double measured_active_hemisphere_total{0.0};
  double measured_active_tactile_sensors{0.0};
  double predicted_active_hemisphere_total{0.0};
  double predicted_active_tactile_sensors{0.0};
  double lost_measured_contact_count{0.0};

  double min_signed_distance_m{0.0};
  double predicted_normal_force_total_n{0.0};
  double min_edge_margin_m{0.0};

  double contact_loss_cost{0.0};
  double support_cost{0.0};
  double edge_cost{0.0};
  double predicted_force_high_cost{0.0};

  double totalCost() const {
    return contact_loss_cost + support_cost + edge_cost +
           predicted_force_high_cost;
  }
};

ObjectContactSupportEvaluation EvaluateObjectContactSupport(
    const GraspState& state,
    const RolloutContext& context,
    const ObjectContactSupportEvaluatorConfig& config = {});

}  // namespace mppi_core
