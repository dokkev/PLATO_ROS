// Copyright 2026
//
// Licensed under the Apache License, Version 2.0.

#pragma once

#include <Eigen/Core>
#include <Eigen/StdVector>

#include <cstddef>
#include <memory>
#include <string>
#include <vector>

#include "mppi_core/core/mppi_config.hpp"
#include "mppi_core/costs/robust_grasp_state_cost.hpp"
#include "mppi_core/disturbance/grasp_disturbance_sampler.hpp"
#include "mppi_core/policy/grasp_action_library.hpp"
#include "mppi_core/rollout/disturbed_grasp_rollout.hpp"
#include "mppi_core/robot/robot_system.hpp"
#include "mppi_core/state/grasp_observation.hpp"
#include "mppi_core/state/grasp_state.hpp"

namespace mppi_core {

struct RobustGraspPolicyConfig {
  MPPIConfig rollout;
  GraspStartConfig start;

  DisturbedGraspRolloutConfig disturbed_rollout;
  GraspDisturbanceSamplerConfig disturbance_sampler;
  RobustGraspStateCostConfig cost;
  GraspActionLibraryConfig action_library;

  double risk_weight{1.0};
  double cvar_tail_fraction{0.25};
  double safe_hold_score_threshold{-1.0};
  double min_required_score_improvement{1.0};
  double action_rate_weight{0.01};

  bool require_both_contact_for_update{true};
  bool return_hold_when_not_ready{true};
};

struct RobustGraspPolicyStatus {
  EIGEN_MAKE_ALIGNED_OPERATOR_NEW

  bool ready{false};
  bool used_hold_fallback{false};

  std::size_t candidate_count{0};
  std::size_t disturbance_count{0};

  double best_score{0.0};
  double best_mean_cost{0.0};
  double best_cvar_cost{0.0};
  std::size_t best_candidate_index{0};
  std::string best_action_name;
  bool selected_hold_by_margin{false};

  double raw_best_score{0.0};
  double raw_best_mean_cost{0.0};
  double raw_best_cvar_cost{0.0};
  std::size_t raw_best_candidate_index{0};
  std::string raw_best_action_name;
  double hold_score_improvement{0.0};

  double hold_score{0.0};
  double hold_mean_cost{0.0};
  double hold_cvar_cost{0.0};
  std::string hold_action_name{"hold"};

  double second_best_score{0.0};
  std::size_t second_best_candidate_index{0};
  std::string second_best_action_name;

  double selected_object_support_cost{0.0};
  std::size_t selected_object_sample_count{0};
  std::size_t selected_object_geometry_query_count{0};
  double selected_predicted_active_hemisphere_total{0.0};
  double selected_measured_active_hemisphere_total{0.0};
  double selected_object_contact_loss_count{0.0};
  double selected_object_edge_margin_m{0.0};

  Eigen::VectorXd selected_qddot;
};

class RobustGraspPolicy {
 public:
  RobustGraspPolicy() = default;

  void Initialize(RobustGraspPolicyConfig config);

  RobotCommand Update(const GraspObservation& observation);

  const RobustGraspPolicyStatus& status() const { return status_; }

 private:
  struct CandidateEvaluationStats;

  GraspState MakeInitialState(const GraspObservation& observation) const;

  double EvaluateCandidate(
      const GraspState& initial_state,
      const ActionSequence& candidate,
      const std::vector<GraspDisturbanceSequence,
                        Eigen::aligned_allocator<GraspDisturbanceSequence>>&
          disturbances,
      const RolloutContext& context,
      double* mean_cost,
      double* cvar_cost,
      CandidateEvaluationStats* stats) const;

  RobotCommand MakeHoldCommand(const GraspObservation& observation) const;
  bool IsReady(const GraspState& state) const;

  RobustGraspPolicyConfig config_;
  RobustGraspPolicyStatus status_;
  std::unique_ptr<GraspDisturbanceSampler> disturbance_sampler_;
  std::unique_ptr<GraspActionLibrary> action_library_;
  std::unique_ptr<RobustGraspStateCost> cost_;
  Eigen::VectorXd last_selected_qddot_;
  bool initialized_{false};
};

}  // namespace mppi_core
