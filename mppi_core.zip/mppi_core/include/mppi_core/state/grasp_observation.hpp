// Copyright 2026
//
// Licensed under the Apache License, Version 2.0.

#pragma once

#include <Eigen/Core>

#include "mppi_core/tactile/tactile_state.hpp"

namespace mppi_core {

struct GraspRolloutConfig;
struct ContactForceCorrectionState;
struct ContactForceProjectionConfig;
struct ContactForceRolloutConfig;
struct PinocchioContactKinematicsContext;

struct GraspObservation {
  EIGEN_MAKE_ALIGNED_OPERATOR_NEW

  Eigen::VectorXd q_meas;
  Eigen::VectorXd qdot_meas;
  Eigen::VectorXd tau_meas;

  Eigen::VectorXd q_ref_current;
  Eigen::VectorXd qdot_ref_current;

  TactileState tactile0_meas;
  TactileState tactile1_meas;

  const PinocchioContactKinematicsContext* tactile0_kinematics{nullptr};
  const PinocchioContactKinematicsContext* tactile1_kinematics{nullptr};
  const GraspRolloutConfig* grasp_rollout_config{nullptr};
  const ContactForceProjectionConfig* contact_force_projection_config{nullptr};
  const ContactForceRolloutConfig* contact_force_rollout_config{nullptr};
  const ContactForceCorrectionState* contact_force_correction_state{nullptr};
  double time_s{0.0};
};

}  // namespace mppi_core
