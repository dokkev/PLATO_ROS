// Copyright 2026
//
// Licensed under the Apache License, Version 2.0.

#pragma once

#include "mppi_core/robot/robot_state.hpp"
#include "mppi_core/tactile/tactile_state.hpp"

namespace mppi_core {

struct GraspState {
  EIGEN_MAKE_ALIGNED_OPERATOR_NEW

  bool valid{false};

  RobotState robot;

  TactileState tactile0;
  TactileState tactile1;
};

inline GraspState MakeGraspState(const RobotState& robot,
                                 const TactileState& tactile0,
                                 const TactileState& tactile1) {
  GraspState state;
  state.robot = robot;
  state.tactile0 = tactile0;
  state.tactile1 = tactile1;
  state.valid = IsValidRobotState(robot) && tactile0.valid && tactile1.valid;
  return state;
}

inline GraspState MakeGraspState(const Eigen::VectorXd& q_des,
                                 const Eigen::VectorXd& qdot_des,
                                 const Eigen::VectorXd& qddot_des,
                                 const Eigen::VectorXd& tau_ff,
                                 const TactileState& tactile0,
                                 const TactileState& tactile1) {
  return MakeGraspState(MakeRobotState(q_des, qdot_des, qddot_des, tau_ff),
                        tactile0, tactile1);
}

}  // namespace mppi_core
