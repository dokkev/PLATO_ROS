// Copyright 2026
//
// Licensed under the Apache License, Version 2.0.

#include "mppi_core/rollout/grasp_state_rollout_model.hpp"

#include <cmath>
#include <cstddef>
#include <pinocchio/algorithm/joint-configuration.hpp>
#include <pinocchio/algorithm/rnea.hpp>
#include <stdexcept>
#include <utility>

#include "mppi_core/contact/contact_force_correction.hpp"
#include "mppi_core/contact/contact_force_projection.hpp"
#include "mppi_core/contact/contact_kinematics.hpp"
#include "mppi_core/rollout/contact_force_rollout.hpp"

namespace mppi_core {
namespace {

TactileState InitialTactilePrediction(const RolloutContext& context,
                                      int tactile_sensor) {
  const TactileState* tactile =
      tactile_sensor == 0 ? context.tactile0 : context.tactile1;
  if (tactile == nullptr) {
    return TactileState{};
  }
  return *tactile;
}

bool HasActiveTactileHemisphere(const TactileState& tactile) {
  for (const auto& hemisphere : tactile.hemispheres) {
    if (hemisphere.contact && hemisphere.cop_sensor_m.allFinite()) {
      return true;
    }
  }
  return false;
}

int ActiveTactileSensorCount(const TactileState& tactile0,
                             const TactileState& tactile1) {
  int count = 0;
  if (HasActiveTactileHemisphere(tactile0)) {
    ++count;
  }
  if (HasActiveTactileHemisphere(tactile1)) {
    ++count;
  }
  return count;
}

const PinocchioContactKinematicsContext* PrimaryKinematics(
    const RolloutContext& context) {
  if (context.tactile0_kinematics != nullptr &&
      IsValidContactKinematicsContext(*context.tactile0_kinematics)) {
    return context.tactile0_kinematics;
  }
  if (context.tactile1_kinematics != nullptr &&
      IsValidContactKinematicsContext(*context.tactile1_kinematics)) {
    return context.tactile1_kinematics;
  }
  if (context.tactile0_kinematics != nullptr) {
    return context.tactile0_kinematics;
  }
  return context.tactile1_kinematics;
}

bool ShouldTryKinematicPatchFallback(TactileRolloutPolicy policy) {
  return policy == TactileRolloutPolicy::kResidualThenKinematicFallback;
}

bool CanUsePinocchioState(const Eigen::Ref<const Eigen::VectorXd>& q,
                          const Eigen::Ref<const Eigen::VectorXd>& v,
                          const Eigen::Ref<const Eigen::VectorXd>& a,
                          const PinocchioContactKinematicsContext* context) {
  return context != nullptr && IsValidContactKinematicsContext(*context) &&
         q.size() == static_cast<Eigen::Index>(context->model->nq) &&
         v.size() == static_cast<Eigen::Index>(context->model->nv) &&
         a.size() == static_cast<Eigen::Index>(context->model->nv);
}

Eigen::VectorXd IntegrateReference(
    const Eigen::Ref<const Eigen::VectorXd>& q,
    const Eigen::Ref<const Eigen::VectorXd>& tangent_step,
    const PinocchioContactKinematicsContext* context) {
  if (CanUsePinocchioState(q, tangent_step, tangent_step, context)) {
    return pinocchio::integrate(*context->model, q, tangent_step);
  }
  if (q.size() != tangent_step.size()) {
    throw std::invalid_argument(
        "GraspStateRolloutModel::Step: q and action dimension mismatch");
  }
  return q + tangent_step;
}

Eigen::VectorXd RneaOrZero(const Eigen::Ref<const Eigen::VectorXd>& q,
                           const Eigen::Ref<const Eigen::VectorXd>& v,
                           const Eigen::Ref<const Eigen::VectorXd>& a,
                           const PinocchioContactKinematicsContext* context) {
  Eigen::VectorXd tau_ff = Eigen::VectorXd::Zero(a.size());
  if (!CanUsePinocchioState(q, v, a, context)) {
    return tau_ff;
  }

  const Eigen::VectorXd rnea =
      pinocchio::rnea(*context->model, *context->data, q, v, a);
  if (rnea.size() == tau_ff.size() && rnea.allFinite()) {
    tau_ff = rnea;
  }
  return tau_ff;
}

bool TryMeasuredTorqueResidual(
    const GraspObservation& observation,
    const PinocchioContactKinematicsContext& kinematics,
    Eigen::VectorXd* tau_residual) {
  if (tau_residual == nullptr ||
      !CanUsePinocchioState(observation.q_meas, observation.qdot_meas,
                            observation.tau_meas, &kinematics)) {
    return false;
  }

  const Eigen::VectorXd zero_acceleration =
      Eigen::VectorXd::Zero(static_cast<Eigen::Index>(kinematics.model->nv));
  const Eigen::VectorXd tau_model =
      pinocchio::rnea(*kinematics.model, *kinematics.data, observation.q_meas,
                      observation.qdot_meas, zero_acceleration);
  if (tau_model.size() != observation.tau_meas.size() ||
      !tau_model.allFinite()) {
    return false;
  }

  *tau_residual = observation.tau_meas - tau_model;
  return tau_residual->allFinite();
}

bool TryResidualAwareTactileTransition(
    const GraspState& state, const TactileState& tactile,
    const PinocchioContactKinematicsContext* kinematics,
    bool allow_residual_projection, const RolloutContext& context, double dt,
    TactileState* tactile_out) {
  if (!allow_residual_projection || tactile_out == nullptr ||
      kinematics == nullptr || !IsValidRobotState(state.robot) ||
      !tactile.valid || !HasActiveTactileHemisphere(tactile) ||
      !IsValidContactKinematicsContext(*kinematics)) {
    return false;
  }

  const auto& contact_kinematics = *kinematics;
  if (state.robot.q_des.size() !=
          static_cast<Eigen::Index>(contact_kinematics.model->nq) ||
      !state.robot.q_des.allFinite()) {
    return false;
  }

  const ContactForceProjectionConfig projection_config =
      context.contact_force_projection_config != nullptr
          ? *context.contact_force_projection_config
          : ContactForceProjectionConfig{};
  const ContactForceRolloutConfig transition_config =
      context.contact_force_rollout_config != nullptr
          ? *context.contact_force_rollout_config
          : ContactForceRolloutConfig{};
  if (!projection_config.enabled ||
      !transition_config.enable_force_projection_update) {
    return false;
  }

  Eigen::VectorXd tau_residual;
  if (context.observation == nullptr ||
      !TryMeasuredTorqueResidual(*context.observation, contact_kinematics,
                                 &tau_residual)) {
    return false;
  }

  RobotState projection_robot = state.robot;
  if (context.observation->q_meas.size() ==
          static_cast<Eigen::Index>(contact_kinematics.model->nq) &&
      context.observation->q_meas.allFinite()) {
    projection_robot.q_des = context.observation->q_meas;
  }

  ContactForceProjectionResult projection =
      ProjectContactForcesFromTorqueResidual(projection_robot, tactile,
                                             tau_residual, contact_kinematics,
                                             projection_config);
  if (!projection.valid) {
    return false;
  }

  if (context.contact_force_correction_state != nullptr) {
    projection.total_normal_force_n =
        ApplyContactForceCorrection(projection.total_normal_force_n,
                                    *context.contact_force_correction_state);
  }

  *tactile_out = tactile;
  StepTactileStateFromProjectedForce(projection, dt, transition_config,
                                     tactile_out);
  return tactile_out->valid;
}

bool HasValidStateVectors(const GraspState& state) {
  return state.tactile0.valid && state.tactile1.valid &&
         state.robot.qdot_des.size() == state.robot.qddot_des.size() &&
         state.robot.qdot_des.size() == state.robot.tau_ff.size() &&
         state.robot.q_des.allFinite() && state.robot.qdot_des.allFinite() &&
         state.robot.qddot_des.allFinite() && state.robot.tau_ff.allFinite();
}

bool StepOneTactileState(const GraspState& robot_rollout_state,
                         const TactileState& tactile_seed,
                         const Eigen::Ref<const Eigen::VectorXd>& tangent_step,
                         const PinocchioContactKinematicsContext* kinematics,
                         bool allow_residual_projection,
                         const RolloutContext& context,
                         TactileRolloutPolicy rollout_policy, double dt,
                         TactileState* tactile_out) {
  if (tactile_out == nullptr) {
    return false;
  }
  if (!tactile_seed.valid) {
    *tactile_out = tactile_seed;
    return false;
  }
  if (!HasActiveTactileHemisphere(tactile_seed)) {
    *tactile_out = tactile_seed;
    return true;
  }

  if (TryResidualAwareTactileTransition(robot_rollout_state, tactile_seed,
                                        kinematics, allow_residual_projection,
                                        context, dt, tactile_out)) {
    return true;
  }

  if (rollout_policy == TactileRolloutPolicy::kResidualRequired) {
    *tactile_out = tactile_seed;
    return false;
  }

  if (!ShouldTryKinematicPatchFallback(rollout_policy) ||
      kinematics == nullptr ||
      !IsValidContactKinematicsInput(robot_rollout_state.robot, tactile_seed,
                                     tangent_step, *kinematics)) {
    *tactile_out = tactile_seed;
    return false;
  }

  const GraspRolloutConfig rollout_config =
      context.grasp_rollout_config != nullptr ? *context.grasp_rollout_config
                                              : GraspRolloutConfig{};
  const auto motions = ComputeHemisphereMotions(
      robot_rollout_state.robot, tactile_seed, tangent_step, *kinematics);
  *tactile_out =
      StepTactileTransition(tactile_seed, motions, dt, rollout_config);
  return tactile_out->valid;
}

}  // namespace

GraspStateRolloutModel::GraspStateRolloutModel(std::size_t joint_dim)
    : GraspStateRolloutModel(joint_dim, GraspStateRolloutConfig{}) {}

GraspStateRolloutModel::GraspStateRolloutModel(std::size_t joint_dim,
                                               GraspStateRolloutConfig config)
    : joint_dim_(joint_dim), config_(std::move(config)) {
  if (joint_dim_ == 0) {
    throw std::invalid_argument(
        "GraspStateRolloutModel: joint_dim must be nonzero");
  }
}

void GraspStateRolloutModel::Step(
    const GraspState& state, const Eigen::Ref<const Eigen::VectorXd>& action,
    const RolloutContext& context, double dt, GraspState* next_state) const {
  if (next_state == nullptr) {
    throw std::invalid_argument(
        "GraspStateRolloutModel::Step: next_state is null");
  }
  if (!std::isfinite(dt) || dt <= 0.0) {
    throw std::invalid_argument(
        "GraspStateRolloutModel::Step: dt must be positive");
  }
  if (state.robot.qdot_des.size() != static_cast<Eigen::Index>(joint_dim_) ||
      state.robot.qddot_des.size() != state.robot.qdot_des.size() ||
      state.robot.tau_ff.size() != state.robot.qdot_des.size() ||
      action.size() != static_cast<Eigen::Index>(joint_dim_)) {
    throw std::invalid_argument(
        "GraspStateRolloutModel::Step: dimension mismatch");
  }
  if (!state.robot.q_des.allFinite() || !state.robot.qdot_des.allFinite() ||
      !state.robot.qddot_des.allFinite() || !state.robot.tau_ff.allFinite() ||
      !action.allFinite()) {
    throw std::invalid_argument(
        "GraspStateRolloutModel::Step: state and action must be finite");
  }

  const Eigen::VectorXd qddot_des = action;
  const Eigen::VectorXd qdot_des = state.robot.qdot_des + qddot_des * dt;
  const Eigen::VectorXd tangent_step = qdot_des * dt;
  const PinocchioContactKinematicsContext* primary_kinematics =
      PrimaryKinematics(context);
  const Eigen::VectorXd q_des =
      IntegrateReference(state.robot.q_des, tangent_step, primary_kinematics);
  const Eigen::VectorXd tau_ff =
      RneaOrZero(q_des, qdot_des, qddot_des, primary_kinematics);

  const TactileState tactile0_seed = state.tactile0.valid
                                         ? state.tactile0
                                         : InitialTactilePrediction(context, 0);
  const TactileState tactile1_seed = state.tactile1.valid
                                         ? state.tactile1
                                         : InitialTactilePrediction(context, 1);
  *next_state = MakeGraspState(q_des, qdot_des, qddot_des, tau_ff,
                               tactile0_seed, tactile1_seed);

  const TactileRolloutPolicy rollout_policy = config_.tactile_rollout_policy;
  TactileState transitioned_tactile0;
  TactileState transitioned_tactile1;
  const bool allow_residual_projection =
      ActiveTactileSensorCount(tactile0_seed, tactile1_seed) == 1;
  const bool tactile0_valid = StepOneTactileState(
      *next_state, tactile0_seed, tangent_step, context.tactile0_kinematics,
      allow_residual_projection, context, rollout_policy, dt,
      &transitioned_tactile0);
  const bool tactile1_valid = StepOneTactileState(
      *next_state, tactile1_seed, tangent_step, context.tactile1_kinematics,
      allow_residual_projection, context, rollout_policy, dt,
      &transitioned_tactile1);

  next_state->tactile0 = transitioned_tactile0;
  next_state->tactile1 = transitioned_tactile1;
  next_state->valid =
      tactile0_valid && tactile1_valid && HasValidStateVectors(*next_state) &&
      ActiveTactileSensorCount(next_state->tactile0, next_state->tactile1) > 0;
}

}  // namespace mppi_core
